from calamity_calendar import run
run()
